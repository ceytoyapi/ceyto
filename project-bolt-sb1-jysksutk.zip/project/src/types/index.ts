export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  price: string;
  category: string;
  features: string[];
}

export interface SEOData {
  title: string;
  description: string;
  keywords: string;
  canonicalUrl?: string;
}

export interface ContactInfo {
  address: string;
  phone1: string;
  phone2: string;
  email: string;
}