import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { contactInfo } from '../data/contact';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-800 via-gray-900 to-black text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-6 h-6">
                  <rect x="5" y="10" width="30" height="20" rx="3" fill="#fff"/>
                </svg>
              </div>
              <h3 className="text-xl font-bold">Masa Örtüsü</h3>
            </div>
            <p className="text-gray-300 mb-4">
              Kaliteli masa örtüsü ve ev tekstili ürünleri ile evinizi güzelleştirin.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400">Hızlı Linkler</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-orange-400 transition-colors">Anasayfa</Link></li>
              <li><Link to="/hakkimizda" className="text-gray-300 hover:text-orange-400 transition-colors">Hakkımızda</Link></li>
              <li><Link to="/urunler" className="text-gray-300 hover:text-orange-400 transition-colors">Ürünler</Link></li>
              <li><Link to="/iletisim" className="text-gray-300 hover:text-orange-400 transition-colors">İletişim</Link></li>
              <li><Link to="/site-haritasi" className="text-gray-300 hover:text-orange-400 transition-colors">Site Haritası</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400">İletişim</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin size={18} className="text-orange-400 mt-1 flex-shrink-0" />
                <span className="text-gray-300 text-sm">{contactInfo.address}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-orange-400" />
                <span className="text-gray-300">{contactInfo.phone1}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-orange-400" />
                <span className="text-gray-300">{contactInfo.phone2}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={18} className="text-orange-400" />
                <span className="text-gray-300">{contactInfo.email}</span>
              </div>
            </div>
          </div>

          {/* Working Hours */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-orange-400">Çalışma Saatleri</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <Clock size={18} className="text-orange-400" />
                <div className="text-gray-300">
                  <p className="text-sm">Pazartesi - Cumartesi</p>
                  <p className="text-sm font-medium">09:00 - 18:00</p>
                </div>
              </div>
              <div className="text-gray-300 text-sm mt-3">
                <p>Pazar: Kapalı</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 Masa Örtüsü. Tüm hakları saklıdır. | 
            <span className="text-orange-400"> SEO ve Web Tasarım: AI Destekli Sistem</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;