import React from 'react';
import { Helmet } from 'react-helmet-async';
import { SEOData } from '../types';

interface SEOProps {
  data: SEOData;
}

const SEO: React.FC<SEOProps> = ({ data }) => {
  return (
    <Helmet>
      <title>{data.title}</title>
      <meta name="description" content={data.description} />
      <meta name="keywords" content={data.keywords} />
      {data.canonicalUrl && <link rel="canonical" href={data.canonicalUrl} />}
      
      {/* Open Graph */}
      <meta property="og:title" content={data.title} />
      <meta property="og:description" content={data.description} />
      <meta property="og:type" content="website" />
      <meta property="og:locale" content="tr_TR" />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={data.title} />
      <meta name="twitter:description" content={data.description} />
      
      {/* Schema.org */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          "name": "Masa Örtüsü",
          "description": data.description,
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Mahmutbey Mah. 42. Ada No: 60",
            "addressLocality": "Bağcılar",
            "addressRegion": "İstanbul",
            "addressCountry": "TR"
          },
          "telephone": "+902126302050",
          "email": "ceyto@ceyto.com",
          "url": "https://masaortusu.com"
        })}
      </script>
    </Helmet>
  );
};

export default SEO;