import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Home, Info, Settings, Package, MapPin, Phone } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const menuItems = [
    { path: '/', label: 'Anasayfa', icon: Home, color: 'bg-orange-500' },
    { path: '/hakkimizda', label: 'Hakkımızda', icon: Info, color: 'bg-red-500' },
    { path: '/cozumler', label: 'Çözümler', icon: Settings, color: 'bg-green-500' },
    { path: '/urunler', label: 'Ürünler', icon: Package, color: 'bg-yellow-500' },
    { path: '/hizmetler', label: 'Hizmet Bölgesi', icon: MapPin, color: 'bg-blue-500' },
    { path: '/iletisim', label: 'İletişim', icon: Phone, color: 'bg-purple-500' }
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-gradient-to-r from-orange-400 via-red-400 to-yellow-400 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-md">
              <svg viewBox="0 0 40 40" className="w-8 h-8">
                <rect x="5" y="10" width="30" height="20" rx="3" fill="#ff6b35" stroke="#333" strokeWidth="1"/>
                <circle cx="12" cy="16" r="1.5" fill="#fff"/>
                <circle cx="20" cy="16" r="1.5" fill="#28a745"/>
                <circle cx="28" cy="16" r="1.5" fill="#ffc107"/>
                <path d="M8 22 L32 22" stroke="#333" strokeWidth="1"/>
                <path d="M8 25 L32 25" stroke="#333" strokeWidth="0.5"/>
              </svg>
            </div>
            <span className="text-white font-bold text-xl hidden sm:block">Masa Örtüsü</span>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden lg:flex space-x-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 ${
                    isActive(item.path)
                      ? `${item.color} text-white shadow-lg`
                      : 'text-white hover:bg-white/20'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden text-white p-2 rounded-lg hover:bg-white/20 transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-white/20">
            <nav className="space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                      isActive(item.path)
                        ? `${item.color} text-white shadow-md`
                        : 'text-white hover:bg-white/20'
                    }`}
                  >
                    <Icon size={20} />
                    <span className="font-medium">{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;