import { useEffect } from 'react';

interface SEOContent {
  title: string;
  content: string;
  keywords: string[];
}

// Otomatik SEO içerik üreteci
export const useSEO = () => {
  const generateDailySEOContent = (): SEOContent[] => {
    const today = new Date();
    const season = getSeason(today);
    const dayOfWeek = today.toLocaleDateString('tr-TR', { weekday: 'long' });
    
    const seoContents: SEOContent[] = [
      {
        title: `${season} Sezonuna Özel Masa Örtüsü Koleksiyonu - ${dayOfWeek}`,
        content: `${season} aylarında evinizdeki masaları güzelleştirmek için özel tasarlanan masa örtüsü koleksiyonumuz. Kaliteli kumaşlar, dayanıklı dikişler ve şık tasarımlarla ${season.toLowerCase()} dekorasyonunuzda fark yaratın.`,
        keywords: [`${season.toLowerCase()} masa örtüsü`, 'mevsimlik ev tekstili', 'masa dekorasyonu']
      },
      {
        title: `Masa Örtüsü Bakım Rehberi - ${today.getFullYear()} Güncel Bilgiler`,
        content: `Masa örtüsü bakım talimatları ve uzun ömürlü kullanım için pratik öneriler. Kumaş türüne göre yıkama, ütüleme ve saklama koşulları hakkında detaylı rehber.`,
        keywords: ['masa örtüsü bakımı', 'ev tekstili temizlik', 'kumaş bakım talimatları']
      },
      {
        title: `${today.getFullYear()} Masa Örtüsü Trendleri ve Renk Seçenekleri`,
        content: `Bu yılın en popüler masa örtüsü trendleri, renk kombinasyonları ve dekorasyon önerileri. Modern ev dekorasyonunda masa örtüsü kullanım ipuçları.`,
        keywords: [`${today.getFullYear()} masa örtüsü trendleri`, 'modern masa dekorasyonu', 'renk trendleri']
      }
    ];

    return seoContents;
  };

  const getSeason = (date: Date): string => {
    const month = date.getMonth() + 1;
    if (month >= 3 && month <= 5) return 'İlkbahar';
    if (month >= 6 && month <= 8) return 'Yaz';
    if (month >= 9 && month <= 11) return 'Sonbahar';
    return 'Kış';
  };

  // Otomatik ping sistemi
  const setupAutoPing = () => {
    const pingSearchEngines = async () => {
      const sitemap = `${window.location.origin}/sitemap.xml`;
      const pingUrls = [
        `https://www.google.com/ping?sitemap=${encodeURIComponent(sitemap)}`,
        `https://www.bing.com/ping?sitemap=${encodeURIComponent(sitemap)}`
      ];

      pingUrls.forEach(async (url) => {
        try {
          await fetch(url, { mode: 'no-cors' });
        } catch (error) {
          console.log('Ping attempt completed');
        }
      });
    };

    // Günlük ping
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0);

    const timeUntilPing = tomorrow.getTime() - now.getTime();
    setTimeout(() => {
      pingSearchEngines();
      setInterval(pingSearchEngines, 24 * 60 * 60 * 1000); // Her 24 saatte bir
    }, timeUntilPing);
  };

  useEffect(() => {
    // SEO sistemini başlat
    setupAutoPing();
    
    // Meta etiketleri güncelle
    const updateMetaTags = () => {
      const dailyContent = generateDailySEOContent()[0];
      
      // Dinamik schema.org güncelleme
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.innerHTML = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Product",
        "name": "Masa Örtüsü",
        "description": dailyContent.content,
        "brand": "Masa Örtüsü",
        "offers": {
          "@type": "Offer",
          "availability": "https://schema.org/InStock",
          "priceCurrency": "TRY"
        }
      });
      
      document.head.appendChild(script);
    };

    updateMetaTags();
  }, []);

  return {
    generateDailySEOContent,
    setupAutoPing
  };
};