import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Shield, Truck, Palette } from 'lucide-react';
import SEO from '../components/SEO';
import ImageGallery from '../components/ImageGallery';
import { seoData } from '../data/seo';
import { products } from '../data/products';

const Home: React.FC = () => {
  const featuredProducts = products.slice(0, 3);
  
  const galleryImages = [
    '/masaortusu.jpeg',
    '/cammika.jpg',
    '/a mika masa koruyucu.jpeg',
    '/a mika masa koruyucuu.jpeg',
    '/masakoruyucumika2144.jpeg'
  ];
  
  const galleryTitles = [
    'Premium Masa Örtüsü Koleksiyonu',
    'Cam Mika Masa Koruyucu',
    'Mika Masa Koruyucu Modeli',
    'Şeffaf Masa Koruyucu Çeşitleri',
    'Premium Mika Koruyucu Sistemi'
  ];

  return (
    <>
      <SEO data={seoData.home} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-100 via-yellow-50 to-red-100 py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
                Kaliteli <span className="text-orange-500">Masa Örtüsü</span> ile 
                Evinizi Güzelleştirin
              </h1>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                25 yıllık deneyimimizle, yüksek kaliteli masa örtüsü ve ev tekstili ürünleri sunuyoruz. 
                Şık tasarımlar, dayanıklı kumaşlar ve uygun fiyatlarla masa dekorasyonunuzda fark yaratın.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/urunler"
                  className="bg-orange-500 text-white px-8 py-4 rounded-full font-semibold hover:bg-orange-600 transition-all duration-300 hover:scale-105 shadow-lg flex items-center justify-center"
                >
                  Ürünleri İncele <ArrowRight className="ml-2" size={20} />
                </Link>
                <Link
                  to="/iletisim"
                  className="border-2 border-orange-500 text-orange-500 px-8 py-4 rounded-full font-semibold hover:bg-orange-500 hover:text-white transition-all duration-300 flex items-center justify-center"
                >
                  İletişime Geç
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="/masaortusu.jpeg"
                alt="Kaliteli masa örtüsü koleksiyonu"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="flex items-center space-x-2">
                  <Star className="text-yellow-500" fill="currentColor" />
                  <span className="font-semibold">4.9/5</span>
                  <span className="text-gray-600">Müşteri Memnuniyeti</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Neden <span className="text-orange-500">Bizi Tercih Etmelisiniz?</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center group-hover:bg-orange-500 transition-colors">
                <Shield className="text-orange-500 group-hover:text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Kalite Garantisi</h3>
              <p className="text-gray-600">Yüksek kaliteli kumaşlar ve uzun ömürlü ürünler</p>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-500 transition-colors">
                <Truck className="text-green-500 group-hover:text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Hızlı Teslimat</h3>
              <p className="text-gray-600">İstanbul içi aynı gün, Türkiye geneli 2-3 gün</p>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="w-16 h-16 mx-auto mb-4 bg-yellow-100 rounded-full flex items-center justify-center group-hover:bg-yellow-500 transition-colors">
                <Palette className="text-yellow-500 group-hover:text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Geniş Renk Seçeneği</h3>
              <p className="text-gray-600">50+ farklı renk ve desen seçeneği</p>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center group-hover:bg-red-500 transition-colors">
                <Star className="text-red-500 group-hover:text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">25 Yıl Deneyim</h3>
              <p className="text-gray-600">Sektörde çeyrek asırlık tecrübe</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-orange-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Öne Çıkan <span className="text-orange-500">Ürünlerimiz</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-orange-500">{product.price}</span>
                    <span className="bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-sm font-medium">
                      {product.category}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/urunler"
              className="bg-orange-500 text-white px-8 py-4 rounded-full font-semibold hover:bg-orange-600 transition-all duration-300 hover:scale-105 shadow-lg inline-flex items-center"
            >
              Tüm Ürünleri Görüntüle <ArrowRight className="ml-2" size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Uploaded Images Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Ürün <span className="text-orange-500">Galerimiz</span>
          </h2>
          <ImageGallery images={galleryImages} titles={galleryTitles} />
        </div>
      </section>
    </>
  );
};

export default Home;