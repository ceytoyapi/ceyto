import React from 'react';
import { MapPin, Truck, Clock, Shield } from 'lucide-react';
import SEO from '../components/SEO';
import { seoData } from '../data/seo';

const Services: React.FC = () => {
  const serviceAreas = [
    { city: 'İstanbul', districts: ['Bağcılar', 'Başakşehir', 'Avcılar', 'Küçükçekmece', 'Bahçelievler'] },
    { city: 'Ankara', districts: ['Çankaya', 'Keçiören', 'Yenimahalle', 'Mamak', 'Sincan'] },
    { city: 'İzmir', districts: ['Konak', 'Karşıyaka', 'Bornova', 'Balçova', 'Gaziemir'] },
    { city: 'Bursa', districts: ['Osmangazi', 'Nilüfer', 'Yıldırım', 'Mudanya', 'Gemlik'] }
  ];

  return (
    <>
      <SEO data={seoData.services} />
      
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Hizmet <span className="text-green-500">Bölgelerimiz</span>
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Türkiye genelinde hızlı ve güvenilir teslimat hizmetimizle 
              kaliteli masa örtüsü ürünlerimizi kapınıza kadar getiriyoruz.
            </p>
          </div>

          {/* Service Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <Truck className="text-green-500" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Hızlı Teslimat</h3>
              <p className="text-gray-600">İstanbul içi aynı gün, diğer şehirler 2-3 gün</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                <Shield className="text-blue-500" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Güvenli Paketleme</h3>
              <p className="text-gray-600">Ürünleriniz hasarsız ulaşması için özel paketleme</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center">
                <Clock className="text-orange-500" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">7/24 Destek</h3>
              <p className="text-gray-600">Her zaman ulaşabileceğiniz müşteri hizmetleri</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-purple-100 rounded-full flex items-center justify-center">
                <MapPin className="text-purple-500" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Geniş Ağ</h3>
              <p className="text-gray-600">81 ile ulaşan güçlü dağıtım ağımız</p>
            </div>
          </div>

          {/* Service Areas */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Ana Hizmet <span className="text-green-500">Bölgelerimiz</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {serviceAreas.map((area, index) => (
                <div key={index} className="border-2 border-green-200 rounded-xl p-6 hover:border-green-500 transition-all duration-300 hover:shadow-lg">
                  <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <MapPin className="text-green-500 mr-2" size={20} />
                    {area.city}
                  </h3>
                  <ul className="space-y-2">
                    {area.districts.map((district, districtIndex) => (
                      <li key={districtIndex} className="text-gray-600 text-sm flex items-center">
                        <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                        {district}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Information */}
          <div className="mt-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl p-8 text-white">
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-6">Teslimat Bilgileri</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <div className="text-4xl font-bold mb-2">0-50₺</div>
                  <div className="text-lg">İstanbul İçi Kargo</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">50-100₺</div>
                  <div className="text-lg">Türkiye Geneli Kargo</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">ÜCRETSİZ</div>
                  <div className="text-lg">500₺ Üzeri Siparişler</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Services;