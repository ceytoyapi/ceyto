import React from 'react';
import { Award, Users, Target, Heart } from 'lucide-react';
import SEO from '../components/SEO';
import { seoData } from '../data/seo';

const About: React.FC = () => {
  return (
    <>
      <SEO data={seoData.about} />
      
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
        {/* Hero Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Hakkımızda
              </h1>
              <p className="text-xl text-gray-700 max-w-3xl mx-auto">
                1999 yılından bu yana masa örtüsü ve ev tekstili sektöründe 
                kaliteli ürünler üretip, müşteri memnuniyetini ön planda tutuyoruz.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <img
                  src="/cammika.jpg"
                  alt="Masa örtüsü üretim atölyesi"
                  className="rounded-2xl shadow-2xl w-full"
                />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Hikayemiz</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  25 yıl önce küçük bir atölyede başladığımız yolculuğumuz, bugün 
                  Türkiye'nin önde gelen masa örtüsü üreticilerinden biri olmamızla 
                  sonuçlandı. Kaliteye olan tutkumuz ve müşteri memnuniyetine verdiğimiz 
                  önem sayesinde binlerce mutlu müşteriye hizmet verdik.
                </p>
                <p className="text-gray-700 mb-8 leading-relaxed">
                  Geleneksel el işçiliği ile modern üretim tekniklerini harmanlayarak, 
                  hem estetik hem de fonksiyonel ürünler üretiyoruz. Her ürünümüz, 
                  evinizdeki masalarınızı güzelleştirmek için özenle tasarlanır.
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-orange-500">25+</div>
                    <div className="text-gray-600">Yıl Deneyim</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-500">10.000+</div>
                    <div className="text-gray-600">Mutlu Müşteri</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Değerlerimiz
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center group-hover:bg-orange-500 transition-colors duration-300">
                  <Award className="text-orange-500 group-hover:text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Kalite</h3>
                <p className="text-gray-600">En yüksek kalite standartlarında üretim</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-500 transition-colors duration-300">
                  <Users className="text-green-500 group-hover:text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Müşteri Odaklılık</h3>
                <p className="text-gray-600">Müşteri memnuniyeti her şeyden önce</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto mb-4 bg-yellow-100 rounded-full flex items-center justify-center group-hover:bg-yellow-500 transition-colors duration-300">
                  <Target className="text-yellow-500 group-hover:text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">İnovasyon</h3>
                <p className="text-gray-600">Sürekli gelişim ve yenilik</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center group-hover:bg-red-500 transition-colors duration-300">
                  <Heart className="text-red-500 group-hover:text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Güven</h3>
                <p className="text-gray-600">25 yıllık güvenilir partnerlik</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Hayalinizdeki Masa Örtüsünü Bulun
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Geniş ürün yelpazemizi keşfedin ve evinize en uygun masa örtüsünü seçin
            </p>
            <Link
              to="/urunler"
              className="bg-white text-orange-500 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-all duration-300 hover:scale-105 shadow-lg inline-flex items-center"
            >
              Ürünleri Keşfet <ArrowRight className="ml-2" size={20} />
            </Link>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;