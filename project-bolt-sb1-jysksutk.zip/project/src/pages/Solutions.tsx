import React from 'react';
import { CheckCircle, Home, Building, Utensils, Coffee } from 'lucide-react';
import SEO from '../components/SEO';

const Solutions: React.FC = () => {
  const solutions = [
    {
      icon: Home,
      title: 'Ev Kullanımı',
      description: 'Yemek odanızı ve mutfağınızı şık masa örtüleri ile dekore edin',
      features: ['Günlük kullanım için dayanıklı', 'Kolay bakım', 'Çok çeşitli renk seçenekleri'],
      color: 'orange'
    },
    {
      icon: Building,
      title: 'Kurumsal Çözümler',
      description: 'Restoranlar, oteller ve iş yerleri için toptan masa örtüsü çözümleri',
      features: ['Toplu sipariş indirimleri', 'Özel tasarım imkanı', 'Hızlı teslimat'],
      color: 'green'
    },
    {
      icon: Utensils,
      title: 'Restoran & Kafe',
      description: 'Profesyonel kullanım için özel üretim masa örtüleri',
      features: ['Leke tutmaz kumaş', 'Ticari yıkamaya uygun', 'Marka logosu baskısı'],
      color: 'red'
    },
    {
      icon: Coffee,
      title: 'Özel Etkinlikler',
      description: 'Düğün, nişan ve özel günler için şık masa dekorasyon çözümleri',
      features: ['Özel renk seçenekleri', 'Nakışlı modeller', 'Kiralama seçeneği'],
      color: 'yellow'
    }
  ];

  return (
    <>
      <SEO data={{
        title: 'Çözümlerimiz - Masa Örtüsü Uygulama Alanları | Ev, Restoran, Otel',
        description: 'Ev, restoran, otel ve özel etkinlikler için masa örtüsü çözümlerimizi keşfedin. Kurumsal toptan satış, özel tasarım ve kiralama seçenekleri.',
        keywords: 'masa örtüsü çözümleri, restoran masa örtüsü, otel tekstili, kurumsal masa örtüsü'
      }} />
      
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Çözümlerimiz
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Her ihtiyaca özel masa örtüsü çözümleri sunuyoruz. Evden iş yerine, 
              özel etkinliklerden kurumsal projelere kadar geniş çözüm yelpazesi.
            </p>
          </div>

          {/* Solutions Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {solutions.map((solution, index) => {
              const Icon = solution.icon;
              const colorClasses = {
                orange: 'from-orange-100 to-orange-200 border-orange-300',
                green: 'from-green-100 to-green-200 border-green-300',
                red: 'from-red-100 to-red-200 border-red-300',
                yellow: 'from-yellow-100 to-yellow-200 border-yellow-300'
              };
              
              return (
                <div
                  key={index}
                  className={`bg-gradient-to-br ${colorClasses[solution.color as keyof typeof colorClasses]} border-2 rounded-2xl p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105`}
                >
                  <div className="flex items-center mb-6">
                    <div className={`w-16 h-16 bg-${solution.color}-500 rounded-full flex items-center justify-center mr-4`}>
                      <Icon className="text-white" size={32} />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">{solution.title}</h3>
                  </div>
                  
                  <p className="text-gray-700 mb-6 leading-relaxed text-lg">
                    {solution.description}
                  </p>
                  
                  <div className="space-y-3">
                    {solution.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <CheckCircle className={`text-${solution.color}-500 mr-3 flex-shrink-0`} size={20} />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Technical Information */}
          <section className="bg-white rounded-2xl shadow-lg p-8 mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Teknik <span className="text-orange-500">Bilgiler</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="border-l-4 border-orange-500 pl-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Kumaş Özellikleri</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• %100 Pamuk ve karışım seçenekleri</li>
                  <li>• 180-300 GSM ağırlık aralığı</li>
                  <li>• Çekmez ve buruşmaz özellik</li>
                  <li>• Antibakteriyel behandlung</li>
                </ul>
              </div>

              <div className="border-l-4 border-green-500 pl-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Ölçü Seçenekleri</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• 140x140 cm (4 kişilik masa)</li>
                  <li>• 160x220 cm (6 kişilik masa)</li>
                  <li>• 160x320 cm (8 kişilik masa)</li>
                  <li>• Özel ölçü üretim imkanı</li>
                </ul>
              </div>

              <div className="border-l-4 border-red-500 pl-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Bakım Talimatları</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• 30°C'de makinede yıkanabilir</li>
                  <li>• Ağartıcı kullanmayın</li>
                  <li>• Orta ısıda ütülenebilir</li>
                  <li>• Gölgede kurutun</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Usage Areas */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Kullanım <span className="text-orange-500">Alanları</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Yemek Odası', desc: 'Günlük öğünler için şık çözümler', image: '/masaortusu.jpeg' },
                { title: 'Mutfak Masası', desc: 'Pratik ve fonksiyonel kullanım', image: '/cammika.jpg' },
                { title: 'Mika Koruyucu', desc: 'Masa yüzeyini koruma çözümleri', image: '/a mika masa koruyucu.jpeg' },
                { title: 'Premium Koruyucu', desc: 'Dayanıklı mika masa koruyucu sistemleri', image: '/masakoruyucumika2144.jpeg' }
              ].map((area, index) => (
                <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
                  <img src={area.image} alt={area.title} className="w-full h-40 object-cover" />
                  <div className="p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">{area.title}</h4>
                    <p className="text-gray-600 text-sm">{area.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </>
  );
};

export default Solutions;