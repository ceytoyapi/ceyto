import React from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

const Sitemap: React.FC = () => {
  const sitePages = [
    { path: '/', title: 'Anasayfa', description: 'Ana sayfa ve genel bilgiler' },
    { path: '/hakkimizda', title: 'Hakkımızda', description: 'Şirket hikayesi ve değerlerimiz' },
    { path: '/cozumler', title: 'Çözümler', description: 'Masa örtüsü uygulama alanları' },
    { path: '/urunler', title: 'Ürünler', description: 'Masa örtüsü ürün kataloğu' },
    { path: '/hizmetler', title: 'Hizmet Bölgesi', description: 'Teslimat alanları ve hizmetler' },
    { path: '/iletisim', title: 'İletişim', description: 'İletişim bilgileri ve form' },
    { path: '/site-haritasi', title: 'Site Haritası', description: 'Tüm sayfa bağlantıları' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-8">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Site <span className="text-blue-500">Haritası</span>
          </h1>
          <p className="text-xl text-gray-700 max-w-2xl mx-auto">
            Websitemizdeki tüm sayfalara buradan kolayca ulaşabilirsiniz.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Tüm Sayfalar</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sitePages.map((page, index) => (
              <Link
                key={index}
                to={page.path}
                className="block bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-xl p-6 hover:border-blue-500 hover:shadow-lg transition-all duration-300 hover:scale-105 group"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600">
                    {page.title}
                  </h3>
                  <ExternalLink className="text-gray-400 group-hover:text-blue-500" size={16} />
                </div>
                <p className="text-gray-600 text-sm">{page.description}</p>
              </Link>
            ))}
          </div>

          <div className="mt-12 border-t border-gray-200 pt-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">SEO ve İndeksleme</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold text-green-800 mb-2">Sitemap XML</h4>
                <p className="text-green-700 text-sm">Arama motorları için XML sitemap otomatik oluşturulur</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 mb-2">Robots.txt</h4>
                <p className="text-blue-700 text-sm">Arama motoru botları için yönlendirme dosyası</p>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <h4 className="font-semibold text-purple-800 mb-2">Otomatik SEO</h4>
                <p className="text-purple-700 text-sm">Günlük SEO optimizasyonu ve içerik güncellemesi</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sitemap;