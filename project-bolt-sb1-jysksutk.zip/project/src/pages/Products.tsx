import React, { useState } from 'react';
import { Star, Filter } from 'lucide-react';
import SEO from '../components/SEO';
import { seoData } from '../data/seo';
import { products } from '../data/products';

const Products: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedColor, setSelectedColor] = useState<string>('all');

  const categories = ['all', 'Premium', 'Pratik', 'Lüks'];
  const colors = ['all', 'Turuncu', 'Krem', 'Bej', 'Sarı', 'Kırmızı', 'Yeşil'];

  const filteredProducts = products.filter(product => {
    const categoryMatch = selectedCategory === 'all' || product.category === selectedCategory;
    const colorMatch = selectedColor === 'all'; // Simplified for demo
    return categoryMatch && colorMatch;
  });

  return (
    <>
      <SEO data={seoData.products} />
      
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Ürün <span className="text-orange-500">Kataloğumuz</span>
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Geniş masa örtüsü koleksiyonumuzdan size en uygun olanı seçin. 
              Her ürün kalite ve estetik mükemmelliği bir araya getiriyor.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex items-center mb-4">
              <Filter className="text-orange-500 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-gray-900">Filtrele</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Category Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Kategori</label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
                        selectedCategory === category
                          ? 'bg-orange-500 text-white shadow-lg scale-105'
                          : 'bg-gray-100 text-gray-700 hover:bg-orange-100'
                      }`}
                    >
                      {category === 'all' ? 'Tümü' : category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Renk</label>
                <div className="flex flex-wrap gap-2">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
                        selectedColor === color
                          ? 'bg-orange-500 text-white shadow-lg scale-105'
                          : 'bg-gray-100 text-gray-700 hover:bg-orange-100'
                      }`}
                    >
                      {color === 'all' ? 'Tümü' : color}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
                <div className="relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {product.category}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Özellikler:</h4>
                    <div className="flex flex-wrap gap-1">
                      {product.features.map((feature, index) => (
                        <span
                          key={index}
                          className="bg-orange-100 text-orange-600 px-2 py-1 rounded-md text-xs font-medium"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-orange-500">{product.price}</span>
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="text-yellow-400" fill="currentColor" size={16} />
                      ))}
                      <span className="text-gray-600 text-sm ml-1">(4.9)</span>
                    </div>
                  </div>

                  <button className="w-full mt-4 bg-orange-500 text-white py-3 rounded-lg font-semibold hover:bg-orange-600 transition-colors duration-300">
                    İletişime Geç
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Products;