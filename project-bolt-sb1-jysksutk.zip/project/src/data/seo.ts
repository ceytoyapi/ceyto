import { SEOData } from '../types';

export const seoData: Record<string, SEOData> = {
  home: {
    title: 'Masa Örtüsü - Kaliteli Masa Tekstili ve Dekorasyon Ürünleri | İstanbul',
    description: 'Türkiye\'nin en kaliteli masa örtüsü ve ev tekstili ürünleri. Premium pamuklu, su geçirmez ve nakışlı masa örtüleri. Hızlı teslimat, uygun fiyat. İstanbul Bağcılar.',
    keywords: 'masa örtüsü, table runner, ev tekstili, masa dekorasyonu, mutfak tekstili, yemek odası, masa aksesuarları, İstanbul'
  },
  about: {
    title: 'Hakkımızda - Masa Örtüsü Uzmanları | 25 Yıllık Deneyim',
    description: '25 yıllık deneyimle masa örtüsü ve ev tekstili sektöründe öncü firmayız. Kaliteli ürünler, müşteri memnuniyeti ve güvenilir hizmet.',
    keywords: 'masa örtüsü firma, ev tekstili şirketi, kaliteli masa örtüsü üretici'
  },
  products: {
    title: 'Ürünlerimiz - Masa Örtüsü Çeşitleri ve Fiyatları | 2024',
    description: 'Geniş masa örtüsü ürün yelpazesi. Premium pamuklu, su geçirmez, nakışlı modeller. Farklı renk ve desenler. Toptan ve perakende satış.',
    keywords: 'masa örtüsü çeşitleri, masa örtüsü fiyatları, pamuklu masa örtüsü, su geçirmez masa örtüsü'
  },
  services: {
    title: 'Hizmetlerimiz - Masa Örtüsü Üretim ve Toptan Satış',
    description: 'Özel dikim, toptan satış, kurumsal çözümler ve hızlı teslimat hizmetleri. Masa örtüsü ihtiyaçlarınız için profesyonel çözümler.',
    keywords: 'masa örtüsü toptan, özel dikim, kurumsal satış, hızlı teslimat'
  },
  contact: {
    title: 'İletişim - Masa Örtüsü Siparişi ve Bilgi | İstanbul Bağcılar',
    description: 'Masa örtüsü siparişi ve bilgi için bize ulaşın. İstanbul Bağcılar\'da showroom. Telefon: 0212 630 20 50. E-posta: ceyto@ceyto.com',
    keywords: 'masa örtüsü sipariş, masa örtüsü iletişim, İstanbul masa örtüsü, Bağcılar'
  }
};