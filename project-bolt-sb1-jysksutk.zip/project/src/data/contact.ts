import { ContactInfo } from '../types';

export const contactInfo: ContactInfo = {
  address: 'Mahmutbey Mah. 42. Ada No: 60, İstoç Bağcılar, İstanbul',
  phone1: '0212 630 20 50',
  phone2: '0544 630 20 50',
  email: 'ceyto@ceyto.com'
};