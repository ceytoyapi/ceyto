import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Premium Pamuklu Masa Örtüsü',
    description: 'Yüksek kaliteli pamuklu kumaştan üretilen, şık ve dayanıklı masa örtüsü',
    image: '/masaortusu.jpeg',
    price: '₺299',
    category: 'Premium',
    features: ['%100 Pamuk', 'Makinede Yıkanabilir', 'Çok Renkli Seçenekler', 'Buruşmaz Kumaş']
  },
  {
    id: '2',
    name: 'Su Geçirmez Masa Örtüsü',
    description: 'Pratik kullanım için su geçirmez ve leke tutmaz özellikli masa örtüsü',
    image: '/cammika.jpg',
    price: '₺199',
    category: 'Pratik',
    features: ['Su Geçirmez', 'Leke Tutmaz', 'Kolay Temizlik', 'Dayanıklı PVC']
  },
  {
    id: '3',
    name: 'Lüks Nakışlı Masa Örtüsü',
    description: 'El işçiliği nakış detayları ile özel tasarım lüks masa örtüsü',
    image: '/a mika masa koruyucu.jpeg',
    price: '₺599',
    category: 'Lüks',
    features: ['El Nakışı', 'Özel Tasarım', 'Premium Kumaş', 'Hediye Paketi']
  },
  {
    id: '4',
    name: 'Mika Masa Koruyucu',
    description: 'Şeffaf ve dayanıklı mika masa koruyucu, masanızı çiziklerden korur',
    image: '/a mika masa koruyucuu.jpeg',
    price: '₺149',
    category: 'Koruyucu',
    features: ['Şeffaf Mika', 'Çizik Koruma', 'Kolay Montaj', 'Su Geçirmez']
  },
  {
    id: '5',
    name: 'Premium Mika Masa Koruyucu',
    description: 'Kalın mika malzemeden üretilen premium masa koruyucu çözümü',
    image: '/masakoruyucumika2144.jpeg',
    price: '₺249',
    category: 'Premium',
    features: ['Kalın Mika', 'Anti-Bakteriyel', 'UV Korumalı', 'Uzun Ömürlü']
  }
];