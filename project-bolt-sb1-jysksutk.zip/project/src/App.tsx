import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Products from './pages/Products';
import Solutions from './pages/Solutions';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Sitemap from './pages/Sitemap';
import { useSEO } from './hooks/useSEO';

function App() {
  // SEO sistemini başlat
  useSEO();

  return (
    <HelmetProvider>
      <Router>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/hakkimizda" element={<About />} />
              <Route path="/cozumler" element={<Solutions />} />
              <Route path="/urunler" element={<Products />} />
              <Route path="/hizmetler" element={<Services />} />
              <Route path="/iletisim" element={<Contact />} />
              <Route path="/site-haritasi" element={<Sitemap />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </HelmetProvider>
  );
}

export default App;